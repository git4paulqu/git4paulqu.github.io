# Huno

Huno is a responsible theme for [Hexo](http://hexo.io/), and it is based on [Uno](https://github.com/daleanthony/uno/).


## Install

```
$ git clone git://github.com/someus/huno.git themes/huno
```

Huno performs well with Hexo 2.5.7.

## Enable
Please modify `theme` setting in `_config.yml` to `huno`.
